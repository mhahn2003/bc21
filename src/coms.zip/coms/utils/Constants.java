package coms.utils;

public class Constants {
}
