package coms;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Slanderer extends Robot {
    public Slanderer(RobotController rc) {
        super(rc);
    }

    public void takeTurn() throws GameActionException {
        super.takeTurn();


    }
}